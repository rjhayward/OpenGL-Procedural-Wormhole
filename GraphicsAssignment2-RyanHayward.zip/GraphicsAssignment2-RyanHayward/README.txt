This is the Space Wormhole Simulator (Background music produced by Ryan Hayward).

Use the mouse to look around the wormhole that you are travelling through, or let go of the mouse and enjoy the ride!

To control the intensity of light, use the F1-F5 keys.

To turn on Wireframe mode, press 2. To switch back to normal mode press 1.

Thanks!
Ryan H

P.s. travelling in the wormhole for too long may be nauseating!
